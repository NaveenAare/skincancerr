%%
clc
clear
close all

%%
[F P] = uigetfile('*.jpg', 'select a test image');
I = imread([P F]);

%% Preprocessing
cform = makecform('srgb2lab');

%% Apply the colorform
lab_he = applycform(I,cform);

%% Segmentation
ab = double(lab_he(:,:,2:3));
nrows = size(ab,1);
ncols = size(ab,2);
ab = reshape(ab,nrows*ncols,2);
nColors = 3;
[cluster_idx, cluster_center] = kmeans(ab,nColors);

%% Label every pixel in tha image using results from K means
pixel_labels = reshape(cluster_idx,nrows,ncols);

%% Create a blank cell array to store the results of clustering
segmented_images = cell(1,3);

%% Create RGB label using pixel_labels
rgb_label = repmat(pixel_labels,[1,1,3]);

for k = 1:nColors
    colors = I;
    colors(rgb_label ~= k) = 0;
    segmented_images{k} = colors;
end

%% Display the contents of the clusters
figure, 
subplot(131);imshow(segmented_images{1});title('Cluster 1'); 
subplot(132);imshow(segmented_images{2});title('Cluster 2');
subplot(133);imshow(segmented_images{3});title('Cluster 3');

x = inputdlg('Enter the cluster no. containing the disease affected skin part only:');
i = str2double(x);

seg_test = segmented_images{i};

%% Feature extraction

%% Low-level features
[A, H, V, D] = dwt2(rgb2gray(seg_test),'db1');
en1 = entropy(A);
ener1 = sum(sum(A.^2));
cor1 = corr(A(:));

[A1, H1, V1, D1] = dwt2(A,'db1');
en2 = entropy(A1);
ener2 = sum(sum(A1.^2));
cor2 = corr(A1(:));

%% Texture features
glcms = graycomatrix(rgb2gray(seg_test));
stats = graycoprops(glcms,{'energy','homogeneity','contrast','correlation'});
conts = stats.Contrast;
ener = stats.Energy;
homo = stats.Homogeneity;
corre = stats.Correlation;

%% Statistical features (Color featurres)
me1 = mean2(seg_test(:,:,1));
me2 = mean2(seg_test(:,:,2));
me3 = mean2(seg_test(:,:,3));

st1 = std2(seg_test(:,:,1));
st2 = std2(seg_test(:,:,2));
st3 = std2(seg_test(:,:,3));

%% Nomlaization
feat1 = [en1 en2 ener1 ener2 cor1 cor2 me1 me2 me3 st1 st2 st3 conts corre ener homo];

%% Selection 
QF = feat1;

%% Classification using PNN
load DF
Tc = [ones(1,240) 1+ones(1,240)];
T = ind2vec(Tc);
net = newpnn(DF,T);
Y = sim(net,QF);
out = vec2ind(Y);



%%
figure,
subplot(1,2,1), imshow(I); title('Input image')
subplot(1,2,2), imshow(seg_test); title('Cancer affected region')

%% Classification result
if mode(out) == 1
    msgbox('Benign Cancer')
else
    msgbox('Malignant Cancer')
end

%% Quality evaluation
figure,
J = uigetfile('*.jpg','select a reference image');
J = imread(J);
[Accuracy, Sensitivity, Fmeasure, Precision, MCC, Dice, Jaccard, Specitivity] = QualityEvaluation(rgb2gray(J), rgb2gray(seg_test));

%%
disp(['Accuracy is ',num2str(Accuracy)])
disp(['sensitivity  is ',num2str(Sensitivity)])
disp(['F-measure is ',num2str(Fmeasure)])
disp(['Precision is ',num2str(Precision)])
disp(['MCC is ',num2str(MCC)])
disp(['Dice is ',num2str(Dice)])
disp(['Jaccard is ',num2str(Jaccard)])
disp(['specificity is ',num2str(Specitivity)])
%%