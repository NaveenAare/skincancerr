%%
clc
clear
close all

%%
[P F] = uigetfile('*.jpg', 'select a test image');
Ia = imread([F P]);
Ia=double(imresize(Ia,[256 256]));

%% Preprocessing
g = fspecial('gaussian');
pre(:,:,1)=imfilter(double(Ia(:,:,1)),g);
pre(:,:,2)=imfilter(double(Ia(:,:,2)),g);
pre(:,:,3)=imfilter(double(Ia(:,:,3)),g);
%% segmentation
I = rgb2gray(uint8(pre));
% Specify initial contour location
mask = zeros(size(I));
mask(25:end-25,25:end-25) = 1;
  % Segment the image using the default method and 300 iterations
bw =activecontour(I,mask,400);
% Display segmented image
seg(:,:,1)=immultiply(bw,uint8(pre(:,:,1)));
seg(:,:,2)=immultiply(bw,uint8(pre(:,:,2)));
seg(:,:,3)=immultiply(bw,uint8(pre(:,:,3)));

seg_test=seg;

figure
subplot(3,3,1)
imshow(Ia)
title('input')
subplot(3,3,2)
imshow(uint8(pre))
title('preprossed')
subplot(3,3,3)
imshow(bw)
title('binary segment')
subplot(3,3,5)
imshow(uint8(seg))
title('segment segment')
subplot(3,3,4)
% Display segmented image
imshow(uint8(pre));hold on
title('Segmented Image');
contour(bw,[0 0],'g'); 

%% Feature extraction

%% Low-level features
[A, H, V, D] = dwt2(rgb2gray(seg_test),'db1');
en1 = entropy(A);
ener1 = sum(sum(A.^2));
cor1 = corr(A(:));
[A1, H1, V1, D1] = dwt2(A,'db1');
en2 = entropy(A1);
ener2 = sum(sum(A1.^2));
cor2 = corr(A1(:));

%% Texture features
glcms = graycomatrix(rgb2gray(seg_test));
stats = graycoprops(glcms,{'energy','homogeneity','contrast','correlation'});
conts = stats.Contrast;
ener = stats.Energy;
homo = stats.Homogeneity;
corre = stats.Correlation;

%% Statistical features (Color featurres)
me1 = mean2(seg_test(:,:,1));
me2 = mean2(seg_test(:,:,2));
me3 = mean2(seg_test(:,:,3));

st1 = std2(seg_test(:,:,1));
st2 = std2(seg_test(:,:,2));
st3 = std2(seg_test(:,:,3));

%% Nomlaization
feat1 = [en1 en2 ener1 ener2 cor1 cor2 me1 me2 me3 st1 st2 st3 conts corre ener homo];

%% Selection 
QF = feat1;

%% Classification using PNN
load DF
Tc = [ones(1,240) 1+ones(1,240)];
T = ind2vec(Tc);
net = newpnn(DF,T);
Y = sim(net,QF);
out = vec2ind(Y);



%%
figure,
subplot(1,2,1), imshow(I); title('Input image')
subplot(1,2,2), imshow(seg_test); title('Cancer affected region')

%% Classification result
if mode(out) == 1
    msgbox('Benign Cancer')
else
    msgbox('Malignant Cancer')
end

%% Quality evaluation
J = uigetfile('*.jpg','select a reference image');
J = imread(J);
J=double(imresize(J,[256 256]));

[Accuracy, Sensitivity, Fmeasure, Precision, MCC, Dice, Jaccard, Specitivity] = QualityEvaluation(rgb2gray(J), rgb2gray(seg_test));

%%
disp(['Accuracy is ',num2str(Accuracy)])
disp(['Sensitivity is ',num2str(Sensitivity)])
disp(['F-measure is ',num2str(Fmeasure)])
disp(['Precision is ',num2str(Precision)])
disp(['MCC is ',num2str(MCC)])
disp(['Dice is ',num2str(Dice)])
disp(['Jaccard is ',num2str(Jaccard)])
disp(['Specitivity is ',num2str(Specitivity)])
%%